
n1=1;
n2=1;
Kd1=50;
Kd2=5;
%HCN=HCP(1);
HCN=0;
%LCN=LCP(1);
LCN=1;
%MCN=MCP(1);
MCN=1;
Kd1eff=Kd1*(LCN+HCN);
Kd2eff=Kd2*(MCN+HCN);
teta=1;
[Y1,Y2] = meshgrid(Yrep1,Yrep2);
%F1=(Y1/Kd1eff)^n1;
%F2=(Y2/Kd2eff)^n2;
F1=(Y1/Kd1).^n1;
F2=(Y2/Kd2).^n2;
F3=teta.*F1.*F2;
AraCmax=40;
AraCT=(AraCmax./(1+F1+F2+F3));



Arab=0.085; % mM
Km3=0.09; %mM
m3=2.8;
roo=(Arab/Km3)^m3;
ro=roo/(1+roo);
AraCc=ro.*AraCT;

Kd3=5;
Kd4=50;

AraC=(1-ro).*AraCT;

u=AraCc./Kd3;
v=AraC./Kd4;

AA=ro+((1-ro).*(Kd3/Kd4));

GFPmax=20;

BB=(Kd3+(AraCT.*(AA))+(GFPmax.*ro));

beta4=0.045;

CC=GFPmax.*((beta4*Kd3)+(AraCT.*ro));

HH=((BB.^2)-(4.*CC)).^0.5;
HHH=(BB-HH)/2;

HHH_no_complex = HHH;
 HHH_no_complex(imag(HHH_no_complex)~=0)= -inf;
 MAX = max(HHH_no_complex(:));
 HHH_no_complex(HHH_no_complex == -inf)= MAX;
 
 HHH_Real=real(HHH);

 %Output=HHH_no_complex;
 Output=HHH_Real;
 
% Outmin1=min(HHH_no_complex);
% Outmin=min(Outmin1);
 % Out=HHH_no_complex./Outmin;
 
 Outmin1=min(HHH_Real);
 Outmin=min(Outmin1);
 Out=HHH_Real./Outmin;
 
GFP=u./(1+u+v);

GFPmin1=min(GFP);
GFPmin=min(GFPmin1);
%Out=GFP./GFPmin;

Z1=Out;
rangeX1 =  In1; %aTc 
rangeX2 = In2; %aTc ng/mL


[X1,X2] = meshgrid(rangeX1,rangeX2);

figure (1)

plot3(X1, X2, Out, '*b','LineWidth',1)


%W=contourf(X1, X2,Out,10,'--');
%h2=heatmap(X1, X2,Bnorm);
%h1=pcolor(X1, X2,log10(Bnorm));
%set(gca,'layer','top')
%set(gca, 'XScale', 'log')
%set(gca, 'YScale', 'log')
%set(gca,'FontSize',24)
%set(gcf,'color','white')
%colorbar
%colormap(jet)

hold on
a = 1;
b = 1;
k1 = 0.7;
k2 = 1.25;

n1 = 0.43075;
n2 = 0.331075;
m = 2;
kd = 19;
zlim([0 1.6])
grid on


beta = 0.045;
func=zeros(11,11);
IPTG=In1;
aTc=In2;
for i=1:length(IPTG)
    for j=1:length(aTc)
        func(i,j) = b.*(((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m + beta)./(1+((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m);
        %func(i,j) = b.*(((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m + beta);
    end
end
Min = min(func);
Min1 = min(Min);
%adding interpolation:
[Xq,Yq] = meshgrid(min(IPTG):max(IPTG),min(aTc):max(aTc));
Vq = interp2(X1,X2,func,Xq,Yq,'spline');

%xlabel("IPTG");
%ylabel("aTc");
%zlabel("GFP");
%legend("GFP vs IPTG & aTc");
hold on 
%drawing of simulation with interpolation (normalized to MIN):

%surf(log10(Xq), log10(Yq), log10(Vq/Min1),'FaceColor','none','EdgeAlpha',0.6,'LineStyle','--','EdgeColor', [0.25 0.25 0.75] )
surf(Xq, Yq, Vq/Min1,'FaceColor','none','EdgeAlpha',0.6,'LineStyle','--','EdgeColor', [0.25 0.25 0.75] )
%surf(log10(Xq), log10(Yq), log10(Vq/Min1),'FaceColor','none','EdgeAlpha',0.6,'LineStyle','--','EdgeColor', 'b' )
zlim([0 1.6])
Rsq = 1 - sum((Z1 - func/Min1).^2)/sum((Z1 - mean(func/Min1)).^2)

RsqL = 1 - sum((log10(Z1) - log10(func/Min1)).^2)/sum((log10(Z1) - mean(log10(func/Min1))).^2)
grid on
ax = gca
ax.LineWidth = 0.5
ax.GridLineStyle = '--'
ax.GridColor = 'k'
ax.GridAlpha = 0.5 % maximum line opacity


zlim([0 50])
xlim([0 128*2])
ylim([0 128*2])

set(gca, 'XScale', 'log')
%set(gca, 'XScale', 'LineWidth','1')
set(gca, 'YScale', 'log')
set(gca, 'ZScale', 'log')
ax=gca;

set(gca,'FontSize',20)
set(gcf,'color','white')

ax = gca
ax.LineWidth = 0.5
ax.GridLineStyle = '--'
ax.GridColor = 'k'
ax.GridAlpha = 0.25 % maximum line opacity

set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gca, 'ZScale', 'log')
