
n1=1;
n2=1;
Kd1=45;
Kd2=4;
%HCN=HCP(1);
HCN=0;
%LCN=LCP(1);
LCN=1;
%MCN=MCP(1);
MCN=1;
Kd1eff=Kd1*(LCN+HCN);
Kd2eff=Kd2*(MCN+HCN);
teta=1;
[Y1,Y2] = meshgrid(Yrep1,Yrep2);
%F1=(Y1/Kd1eff)^n1;
%F2=(Y2/Kd2eff)^n2;
F1=(Y1/Kd1).^n1;
F2=(Y2/Kd2).^n2;
F3=teta.*F1.*F2;

Z=(1./(1+F1+F2+F3));
MMM=min(Z);
MM=min(MMM);
Z1=(Z./MM);
Z2=(Z1);


rangeX1 =  In1; %aTc 
rangeX2 = In2; %aTc ng/mL


[X1,X2] = meshgrid(rangeX1,rangeX2);
figure ()

%h1=pcolor(log10(X1), log10(X2),log10(Y1));
%W=contourf(X1, X2,log10(H1));
%W=contourf(X1, X2,Z2,10,'--');
plot3(log10(X1), log10(X2), Z2, '*r','LineWidth',1)
plot3(X1, X2, Z2, '*r','LineWidth',1)
%h2=heatmap(X1, X2,Bnorm);
%h1=pcolor(X1, X2,log10(Bnorm));
%set(gca,'layer','top')
%set(gca, 'XScale', 'log')
%set(gca, 'YScale', 'log')
%set(gca,'FontSize',28)
%set(gcf,'color','white')
%colorbar
%caxis([0 1.6])
%colormap(jet)


hold on
a = 1;
b = 1;
k1 = 1.25;
k2 = 0.7;
n1 = 0.3225;
n2 = 0.256;

grid on

IPTG=In1;
aTc=In2;
m = 1,
kd = 1;
beta = 0;
func=zeros(11,11);
for i=1:length(IPTG)
    for j=1:length(aTc)
        %func(i,j) = b.*(((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m + beta)./(1+((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m);
        func(i,j) = b.*(((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m + beta);
    end
end
Min = min(func);
Min1 = min(Min);
%adding interpolation:
[Xq,Yq] = meshgrid(min(IPTG):max(IPTG),min(aTc):max(aTc));
Vq = interp2(X1,X2,func,Xq,Yq,'spline');

%xlabel("IPTG");
%ylabel("aTc");
%zlabel("GFP");
%legend("GFP vs IPTG & aTc");
hold on 
%drawing of simulation with interpolation (normalized to MIN):

%surf(log10(Xq), log10(Yq), log10(Vq/Min1),'FaceColor','none','EdgeAlpha',0.6,'LineStyle','--','EdgeColor', [0.75 0.25 0.25] )
surf(Xq, Yq, Vq/Min1,'FaceColor','none','EdgeAlpha',0.6,'LineStyle','--','EdgeColor', [0.75 0.25 0.25] )
%surf(log10(Xq), log10(Yq), log10(Vq/Min1),'FaceColor','none','EdgeAlpha',0.6,'LineStyle','--','EdgeColor', 'b' )
%zlim([0 1.6])
Rsq = 1 - sum((Z1 - func/Min1).^2)/sum((Z1 - mean(func/Min1)).^2)

GFPL=log10(Z1);
FuncL=log10(func/Min1);

RsqL = 1 - sum((GFPL - FuncL).^2)/sum((GFPL - mean(FuncL)).^2)

grid on
ax = gca
ax.LineWidth = 0.5
ax.GridLineStyle = '--'
ax.GridColor = 'k'
ax.GridAlpha = 0.5 % maximum line opacity


zlim([0 50])
xlim([0 128*2])
ylim([0 128*2])

set(gca, 'XScale', 'log')
%set(gca, 'XScale', 'LineWidth','1')
set(gca, 'YScale', 'log')
set(gca, 'ZScale', 'log')
ax=gca;

set(gca,'FontSize',20)
set(gcf,'color','white')

ax = gca
ax.LineWidth = 0.5
ax.GridLineStyle = '--'
ax.GridColor = 'k'
ax.GridAlpha = 0.25 % maximum line opacity

set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gca, 'ZScale', 'log')


%IPTG=log10(rangeX1);
%aTc=log10(rangeX2);
