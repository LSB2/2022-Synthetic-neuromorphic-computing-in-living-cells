Kd1h=8;
PT12=10;



b=Kd1h+PT12-7.*YT1;
c=Kd1h.*YT1;
g=((b.^2)+(4.*c)).^0.5;
Yact1=1.*([(-b+g)./2]);

n1=1

Kd2h=4;
n2=1.25;

%************************************
%[Y1,Y2] = meshgrid(Yact1,Yrep2);


%teta=1;
%Kd1h1=100;

%F1=(Y1/Kd1h1).^n1;

%F2=((Y2/Kd2h).^n2);
%F3=teta.*F1.*F2;

%**************************************


%Y1=Yact1;
%Y2=Yrep2;
teta=1;
Kd1h1=Kd1h;

Y1=(Yact1/Kd1h1).^n1;


Y2=((Yrep2/Kd2h).^n2);

[F1,F2] = meshgrid(Y1,Y2);
F3=teta.*F2.*(F1);

ba=0.0002;

ZF=(1+F1+F2+F3+ba);

Z=((F1+ba))./(1+F1+F2+F3+ba);
MMM=min(Z);
MM=min(MMM);
Z1=(Z./MM);
%Z2=1.2.*log10(Z1)+0.0001;

Z2=1.*log10(Z1);

rangeX1 =  In1; %aTc 
rangeX2 = In2; %aTc ng/mL


[X1,X2] = meshgrid(rangeX1,rangeX2);
figure ()

%h1=pcolor(log10(X1), log10(X2),log10(Y1));
%W=contourf(X1, X2,log10(H1));
%W=contourf(X1, X2,Z2,10,'--');
plot3(log10(X1), log10(X2), Z2, '*r','LineWidth',1)
%h2=heatmap(X1, X2,Bnorm);
%h1=pcolor(X1, X2,log10(Bnorm));
%set(gca,'layer','top')
%set(gca, 'XScale', 'log')
%set(gca, 'YScale', 'log')
%set(gca,'FontSize',28)
%set(gcf,'color','white')
%colorbar
%caxis([0 1.6])
%colormap(jet)


hold on


k1 = 1.25;
k2 = 1.25;

n1 = 0.41*1.1;
n2 = 0.51*1.1;
m = 1;
kd = 2000;

grid on

IPTG=In1;
aTc=In2;
m = 1,
kd = 1000;
beta = 0;
func=zeros(7,7);
for i=1:length(IPTG)
    for j=1:length(aTc)
        %func(i,j) = b.*(((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m + beta)./(1+((a.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m);
        func(i,j) = 1.*(((1.*(IPTG(i)/k1).^n1 .*(aTc(j)/k2).^n2)./kd).^m + beta);
    end
end
Min = min(func);
Min1 = min(Min);
%adding interpolation:
[Xq,Yq] = meshgrid(min(IPTG):max(IPTG),min(aTc):max(aTc));
Vq = interp2(X1,X2,func,Xq,Yq,'spline');

xlabel("IPTG");
ylabel("aTc");
%zlabel("GFP");
%legend("GFP vs IPTG & aTc");
hold on 
%drawing of simulation with interpolation (normalized to MIN):

surf(log10(Xq), log10(Yq), 1.*log10(Vq/Min1),'FaceColor','none','EdgeAlpha',1,'LineStyle','--','EdgeColor', [1 0 0] )
%surf(log10(Xq), log10(Yq), log10(Vq/Min1),'FaceColor','none','EdgeAlpha',0.6,'LineStyle','--','EdgeColor', 'b' )
zlim([0 1.95])
%xlim([0 2])
%ylim([0 2])
Rsq = 1 - sum((Z1 - func/Min1).^2)/sum((Z1 - mean(func/Min1)).^2)

GFPL=Z2;
FuncL=1*log10(func/Min1);

RsqL = 1 - sum((GFPL - FuncL).^2)/sum((GFPL - mean(FuncL)).^2)


grid on
ax = gca
ax.LineWidth = 0.5
ax.GridLineStyle = '--'
ax.GridColor = 'k'
ax.GridAlpha = 0.5 % maximum line opacity


%IPTG=log10(rangeX1);
%aTc=log10(rangeX2);
